package com.ramesh.expenses

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Tx(val id: String, val ts: Long, val amount: Double, val debit: Boolean,
              val merchant: String, val body: String, var category: String?)

val CATEGORIES = listOf("Fuel", "Food", "Groceries", "Shopping", "Bills", "Travel",
    "Health", "Entertainment", "EMI/Rent", "Other")

// Default keyword -> category. Users' own choices are learned and saved on top of this.
val DEFAULT_KEYWORDS = mapOf(
    "Fuel" to listOf("petrol", "petroleum", "fuel", "hpcl", "bpcl", "iocl", "indian oil", "shell", "bunk"),
    "Food" to listOf("swiggy", "zomato", "restaurant", "cafe", "hotel", "dominos", "kfc", "bakery"),
    "Groceries" to listOf("bigbasket", "dmart", "grocery", "supermarket", "blinkit", "zepto", "mart"),
    "Shopping" to listOf("amazon", "flipkart", "myntra", "ajio", "store"),
    "Bills" to listOf("tneb", "electricity", "airtel", "jio", "recharge", "broadband", "dth", "water"),
    "Travel" to listOf("uber", "ola", "irctc", "redbus", "metro", "rapido"),
    "Health" to listOf("pharmacy", "hospital", "apollo", "medplus", "clinic", "medical"),
    "Entertainment" to listOf("netflix", "spotify", "bookmyshow", "hotstar", "prime"),
    "EMI/Rent" to listOf("emi", "rent", "loan")
)

object Store {
    private lateinit var ctx: Context
    private val prefs get() = ctx.getSharedPreferences("exp", Context.MODE_PRIVATE)
    fun init(c: Context) { ctx = c.applicationContext }

    fun load(): MutableList<Tx> {
        val arr = JSONArray(prefs.getString("tx", "[]"))
        return MutableList(arr.length()) {
            val o = arr.getJSONObject(it)
            Tx(o.getString("id"), o.getLong("ts"), o.getDouble("amt"), o.getBoolean("debit"),
                o.getString("m"), o.getString("body"), o.optString("cat").ifEmpty { null })
        }
    }

    fun save(list: List<Tx>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("ts", it.ts).put("amt", it.amount)
                .put("debit", it.debit).put("m", it.merchant).put("body", it.body)
                .put("cat", it.category ?: ""))
        }
        prefs.edit().putString("tx", arr.toString()).apply()
    }

    fun learned(): MutableMap<String, String> {
        val o = JSONObject(prefs.getString("learned", "{}"))
        return o.keys().asSequence().associateWith { o.getString(it) }.toMutableMap()
    }
    fun learn(merchant: String, cat: String) {
        val m = learned(); m[merchant.lowercase()] = cat
        prefs.edit().putString("learned", JSONObject(m as Map<*, *>).toString()).apply()
    }

    fun categorize(merchant: String, body: String): String? {
        val text = "$merchant $body".lowercase()
        learned().entries.firstOrNull { merchant.lowercase() == it.key }?.let { return it.value }
        DEFAULT_KEYWORDS.forEach { (cat, words) -> if (words.any { text.contains(it) }) return cat }
        return null // unknown -> user must fill in
    }

    // Adds a parsed SMS; returns true if new
    fun add(id: String, ts: Long, body: String): Boolean {
        val p = SmsParser.parse(body) ?: return false
        val list = load()
        if (list.any { it.id == id }) return false
        val cat = if (p.debit) categorize(p.merchant, body) else "Income"
        list.add(Tx(id, ts, p.amount, p.debit, p.merchant, body, cat))
        save(list); return true
    }

    fun setCategory(id: String, cat: String) {
        val list = load()
        list.firstOrNull { it.id == id }?.let { tx ->
            tx.category = cat
            if (tx.merchant.isNotBlank()) learn(tx.merchant, cat)
            // apply to other pending txns from same merchant
            list.filter { it.category == null && it.merchant.equals(tx.merchant, true) }
                .forEach { it.category = cat }
        }
        save(list)
    }
}
