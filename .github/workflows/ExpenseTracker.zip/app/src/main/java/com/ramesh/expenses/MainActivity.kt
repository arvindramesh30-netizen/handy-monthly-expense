package com.ramesh.expenses

import android.Manifest
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import java.util.Calendar

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        Store.init(this)
        setContent { MaterialTheme { App() } }
    }

    private fun importInbox() {
        val since = Calendar.getInstance().apply { add(Calendar.MONTH, -2); set(Calendar.DAY_OF_MONTH, 1) }.timeInMillis
        contentResolver.query(Uri.parse("content://sms/inbox"), arrayOf("_id", "body", "date"),
            "date >= ?", arrayOf(since.toString()), "date DESC")?.use { c ->
            while (c.moveToNext()) Store.add("inbox-${c.getLong(0)}", c.getLong(2), c.getString(1) ?: "")
        }
    }

    @Composable
    fun App() {
        var txs by remember { mutableStateOf(Store.load()) }
        val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            importInbox(); txs = Store.load()
        }
        LaunchedEffect(Unit) {
            perm.launch(arrayOf(Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS))
        }
        val cal = Calendar.getInstance()
        fun ym(t: Long) = Calendar.getInstance().apply { timeInMillis = t }.let { it.get(Calendar.YEAR) * 12 + it.get(Calendar.MONTH) }
        val now = cal.get(Calendar.YEAR) * 12 + cal.get(Calendar.MONTH)
        val spend = txs.filter { it.debit && it.category != null }
        val cur = spend.filter { ym(it.ts) == now }.groupBy { it.category!! }.mapValues { e -> e.value.sumOf { it.amount } }
        val prev = spend.filter { ym(it.ts) == now - 1 }.groupBy { it.category!! }.mapValues { e -> e.value.sumOf { it.amount } }
        val pending = txs.filter { it.debit && it.category == null }
        val curT = cur.values.sum(); val prevT = prev.values.sum()

        LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Text("This month: ₹%.0f".format(curT), style = MaterialTheme.typography.headlineSmall)
                Text("Last month: ₹%.0f  (%s₹%.0f)".format(prevT, if (curT >= prevT) "+" else "-", kotlin.math.abs(curT - prevT)))
                Button(onClick = { importInbox(); txs = Store.load() }) { Text("Refresh from SMS") }
            }
            if (pending.isNotEmpty()) {
                item { Text("⚠ Category needed (${pending.size})", color = Color.Red, style = MaterialTheme.typography.titleMedium) }
                items(pending, key = { it.id }) { t ->
                    Column(Modifier.fillMaxWidth().background(Color(0xFFFFEBEE)).padding(10.dp)) {
                        Text("₹%.0f  →  %s".format(t.amount, t.merchant.ifBlank { "Unknown merchant" }), color = Color.Red)
                        Text(t.body.take(90), style = MaterialTheme.typography.bodySmall)
                        Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            // horizontally scrollable chip strip
                            androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(CATEGORIES) { c ->
                                    AssistChip(onClick = { Store.setCategory(t.id, c); txs = Store.load() }, label = { Text(c) })
                                }
                            }
                        }
                    }
                }
            }
            item { Text("By category", style = MaterialTheme.typography.titleMedium) }
            items((cur.keys + prev.keys).toSortedSet().toList()) { c ->
                val a = cur[c] ?: 0.0; val b = prev[c] ?: 0.0; val d = a - b
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(c); Text("₹%.0f vs ₹%.0f".format(a, b))
                    Text("%s₹%.0f".format(if (d >= 0) "▲" else "▼", kotlin.math.abs(d)),
                        color = if (d > 0) Color.Red else Color(0xFF2E7D32))
                }
            }
        }
    }
}
