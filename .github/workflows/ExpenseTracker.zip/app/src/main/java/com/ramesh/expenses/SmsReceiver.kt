package com.ramesh.expenses

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Store.init(c)
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        val ts = msgs.firstOrNull()?.timestampMillis ?: System.currentTimeMillis()
        Store.add("live-$ts-${body.hashCode()}", ts, body)
    }
}
