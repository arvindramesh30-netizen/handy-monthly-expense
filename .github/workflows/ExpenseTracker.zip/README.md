# Setup
1. Android Studio -> New Project -> "Empty Activity" (Jetpack Compose), package `com.ramesh.expenses`.
2. Copy the 4 .kt files from app/src/main/java/com/ramesh/expenses/ into the same package folder.
3. Merge the two <uses-permission> lines and the <receiver> block from AndroidManifest.xml into yours.
4. Run on a phone (not emulator) and allow SMS permission.
